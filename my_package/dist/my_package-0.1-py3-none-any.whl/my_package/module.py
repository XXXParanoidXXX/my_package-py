# my_package/module.py
def hello_world():
    return "Hello, World!"

