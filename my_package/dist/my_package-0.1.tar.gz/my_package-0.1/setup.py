# setup.py
from setuptools import setup, find_packages

setup(
    name="my_package",
    version="0.1",
    packages=find_packages(),
    install_requires=[],  # Aqui você pode adicionar dependências, se houver
    description="Um pacote simples para exemplo",
    author="Paranoid",
    author_email="seuemail@example.com",
    url="https://github.com/XXXParanoidXXX/my_package-py.git",
)