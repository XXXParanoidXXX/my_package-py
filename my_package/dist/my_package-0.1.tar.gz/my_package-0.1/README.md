# My Package

Este é um pacote simples de exemplo em Python.